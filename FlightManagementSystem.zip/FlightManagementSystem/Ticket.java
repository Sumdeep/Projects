import java.lang.*;
import java.io.*;
import java.util.*;

public class Ticket {

    public ArrayList<FlightSegmentReservation> segments;
    public Passenger passenger;

    public Ticket() {

    }

    public Ticket(ArrayList<FlightSegmentReservation> segments, Passenger passenger) {
        this.segments = segments;
        this.passenger = passenger;
    }

    //COMPUTE FINAL PRICE OF ALL FLIGHTS FOR PARTICULAR PASSENGER
    public void compPrice() {
        int finalPrice = 0;
        for (int index  = 0; index < segments.size(); index++) {
            FlightSegmentReservation fs = segments.get(index);
            Flight f = fs.getFlight();
            finalPrice = finalPrice + (fs.getType() + f.getPrice());
        }
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.printf("TOTAL PRICE OF FLIGHTS ARE : %d\n",finalPrice);
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
    }

    public ArrayList<FlightSegmentReservation> getSegments() {
        return segments;
    }

    public void setSegments(ArrayList<FlightSegmentReservation> segments) {
        this.segments = segments;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }
}
