import java.lang.*;

public class FlightSegmentReservation {

    public Flight flight;
    public int type;

    public FlightSegmentReservation() {

    }

    public FlightSegmentReservation(Flight flight, int type)
    {
        this.flight = flight;
        this.type = type;
    }

    public void computePrice() {

    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
