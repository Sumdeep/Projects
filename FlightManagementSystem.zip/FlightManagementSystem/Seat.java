import java.lang.*;

public class Seat {

  public int number;

  public Seat() {

  }

  public Seat(int number) {
    this.number = number;
  }

  public int getNumber() {
    return number;
  }

  public void setNumber(int number) {
    this.number = number;
  }
}
