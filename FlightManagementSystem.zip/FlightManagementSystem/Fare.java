import java.lang.*;

public class Fare {

  public int price;

  public Fare() {

  }

  public Fare(int price) {
    this.price = price;
  }

  public int getPrice() {
    return price;
  }

  public void setPrice(int price) {
    this.price = price;
  }
}
