import java.lang.*;
import java.io.*;
import java.sql.Time;
import java.util.*;

public class Mainprogram {

    public static void main(String args[]) {

        //itinerary objects
        Itinerary itinerary1 = new Itinerary("India","Canada");
        Itinerary itinerary2 = new Itinerary("Austraila","India");

        //departure date objects
        Date date = new Date();
        DepartureDate departureDate1 = new DepartureDate(date,new Time(date.getTime()));
        DepartureDate departureDate2 = new DepartureDate(date,new Time(date.getTime()));

        //flights objects
        Flight flight1 = new Flight("AC23233",itinerary1,departureDate1,"John",5000);
        Flight flight2 = new Flight("RR55233",itinerary2,departureDate2,"Joseph",4000);
        Flight flight3 = new Flight("WR55277",itinerary1,departureDate1,"Micky",8000);
        Flight flight4 = new Flight("TR55244",itinerary2,departureDate2,"Jacky",9000);

        //creating flightsarray
        ArrayList<Flight> flightArray = new ArrayList<Flight>();
        flightArray.add(flight1);
        flightArray.add(flight2);
        flightArray.add(flight3);
        flightArray.add(flight4);

        //object of flight repository
        FlightRepository flightRepository = new FlightRepository(flightArray);

        //Flight segment reservation class objects
        // 1 - ECONOMICS CLASS
        // 2 - BUISNESS CLASS
        FlightSegmentReservation flightSegmentReservation1 = new FlightSegmentReservation(flight1,1);
        FlightSegmentReservation flightSegmentReservation2 = new FlightSegmentReservation(flight2,2);
        FlightSegmentReservation flightSegmentReservation3 = new FlightSegmentReservation(flight3,1);
        FlightSegmentReservation flightSegmentReservation4 = new FlightSegmentReservation(flight4,2);

        ArrayList<FlightSegmentReservation> flightsegmentArray1 = new ArrayList<FlightSegmentReservation>();
        flightsegmentArray1.add(flightSegmentReservation1);
        flightsegmentArray1.add(flightSegmentReservation2);

        ArrayList<FlightSegmentReservation> flightsegmentArray2 = new ArrayList<FlightSegmentReservation>();
        flightsegmentArray2.add(flightSegmentReservation3);
        flightsegmentArray2.add(flightSegmentReservation4);

        flightRepository.listFlights();

        //Passenger class objects
        Passenger passenger1 = new Passenger("Steve");
        Passenger passenger2 = new Passenger("Mark");

        passenger1.bookFlight(flight1);
        passenger1.bookFlight(flight2);

        passenger2.bookFlight(flight3);
        passenger2.bookFlight(flight4);

        //Ticket class objects
        Ticket ticket1 = new Ticket(flightsegmentArray1,passenger1);
        Ticket ticket2 = new Ticket(flightsegmentArray2,passenger2);

        passenger1.listFlights();
        ticket1.compPrice();

        passenger2.listFlights();
        ticket2.compPrice();
    }
}