import java.lang.*;
import java.io.*;
import java.util.*;

public class FlightRepository {

  ArrayList<Flight> flights;

  public FlightRepository() {

  }

  public FlightRepository(ArrayList<Flight> flights) {
    this.flights = flights;
  }

  public void addFlight(Flight flight) {
    this.flights.add(flight);
  }

  public void removeFlight(Flight flight) {
    for (int index = 0; index <  this.flights.size(); index++) {
      Flight f = this.flights.get(index);
      if (f.number == flight.number) {
        this.flights.remove(index);
        break;
      }
    }
  }

  public void listFlights() {
    System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
    System.out.println("++++++++++++++FLIGHT LIST++++++++++++++++++++\n");
    for (int index = 0; index < this.flights.size(); index++) {
      Flight f = this.flights.get(index);
      System.out.format("FLIGHT NUMBER : %s\n",f.number);
    }
    System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
  }

  public ArrayList<Flight> getFlights() {
    return flights;
  }

  public void setFlights(ArrayList<Flight> flights) {
    this.flights = flights;
  }
}
